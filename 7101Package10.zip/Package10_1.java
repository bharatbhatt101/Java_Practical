
//Create a Java program to create a package with public class and public members to be accessed in another class.

package mypackage;

public class Package10_1 {
    public int x = 42;

    public Package10_1() {
       
    }

    public void display() {
        System.out.println("This is a public method from Package10_1.");
    }
}