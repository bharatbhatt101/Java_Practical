
//Create a Java program to create a package with public class and public members to be accessed in another class.


package mypackage;

public class Package10_2 {
    public static void main(String[] args) {
        Package10_1 p = new Package10_1();

        System.out.println("Accessing value of x from class Package10_1: " + p.x);
        p.display();
    }
}